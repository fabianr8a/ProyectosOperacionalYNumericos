from controller import mainframe

mainframe.app.mainloop()

exit(code=0x0)
