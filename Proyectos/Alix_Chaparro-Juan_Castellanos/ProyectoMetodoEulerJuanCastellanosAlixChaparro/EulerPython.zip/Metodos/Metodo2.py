import tkinter
from tkinter import *
from tkinter import ttk, font
from tkinter import messagebox as MessageBox
import getpass

class Metodo():
    def __init__(self,auxH,auxXF,auxYi):

        self.h = auxH
        self.xf = auxXF
        self.yi = auxYi
        self.raiz = Tk()
        self.raiz.title("<- Método Euler Resultados->")
        self.raiz.resizable(0, 0)

        fuente = tkinter.font.Font(weight='bold')
        self.marco = ttk.Frame(self.raiz, borderwidth=2, relief="groove", padding=(10, 10))
        self.enca1 = ttk.Label(self.marco, text="Iteración", font="Arial", padding=(5, 5), anchor="w")
        self.enca2 = ttk.Label(self.marco, text="x", font="Arial", padding=(5, 5), anchor="w")
        self.enca3 = ttk.Label(self.marco, text="y", font="Arial", padding=(5, 5), anchor="w")
        self.enca4 = ttk.Label(self.marco, text="f(x,y)", font="Arial", padding=(5, 5), anchor="w")
        #---------------------------------------------------------------------
        tamanoVectores = int(self.xf / self.h) + 1
        self.vec_x = []
        self.vec_y = []

        for i in range(0, tamanoVectores):
            self.vec_y.append(0)
            if i == 0:
                self.vec_x.append(0)
            else:
                self.vec_x.append(round((self.vec_x[i - 1] + self.h), 2))

        for i in range(0, len(self.vec_x)):
            if (i == 0):
                self.vec_y[i] = self.yi
                self.etiq1 = ttk.Label(self.marco, text=f"{i}",font=fuente, padding=(5, 5), anchor="w")
                self.etiq2 = ttk.Label(self.marco, text=f"{self.vec_x[i]}",font=fuente, padding=(5, 5),anchor="w")
                self.etiq3 = ttk.Label(self.marco, text=f"{self.vec_y[i]}",font=fuente, padding=(5, 5),anchor="w")
                self.etiq4 = ttk.Label(self.marco, text=f"{self.function(self.vec_x[i], self.vec_y[i])}",font=fuente,
                                       padding=(5, 5),anchor="w")
                self.marco.grid(column=0, row=0)
                self.etiq1.grid(column=1, row=i+1)
                self.etiq2.grid(column=2, row=i+1)
                self.etiq3.grid(column=3, row=i+1)
                self.etiq4.grid(column=4, row=i+1)
            else:
                self.vec_y[i] = self.vec_y[i - 1] + (self.h * self.function(self.vec_x[i - 1], self.vec_y[i - 1]))

                self.etiq1 = ttk.Label(self.marco, text=f"{i}", font=fuente, padding=(5, 5),anchor="w")
                self.etiq2 = ttk.Label(self.marco, text=f"{self.vec_x[i]}", font=fuente, padding=(5, 5),anchor="w")
                self.etiq3 = ttk.Label(self.marco, text=f"{self.vec_y[i]}", font=fuente, padding=(5, 5),anchor="w")
                self.etiq4 = ttk.Label(self.marco,
                                       text=f"{self.function(self.vec_x[i], self.vec_y[i])}",
                                       font=fuente, padding=(5, 5),anchor="w")
                self.marco.grid(column=0, row=0)
                self.etiq1.grid(column=1, row=i+1)
                self.etiq2.grid(column=2, row=i+1)
                self.etiq3.grid(column=3, row=i+1)
                self.etiq4.grid(column=4, row=i+1)

            self.enca1.grid(column=1, row=0)
            self.enca2.grid(column=2, row=0)
            self.enca3.grid(column=3, row=0)
            self.enca4.grid(column=4, row=0)

        self.raiz.mainloop()

    def function(self,x, y):
        ecuacion = x - y + 4
        return ecuacion

def main():
    mi_app = Metodo()
    return 0


if __name__ == '__main__':
    main()





