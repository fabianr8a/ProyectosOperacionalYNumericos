# -*- coding: utf-8 -*-
import tkinter
from tkinter import *
from tkinter import ttk, font
from tkinter import messagebox as MessageBox
import getpass

from Metodo2 import Metodo


class Aplicacion():
    def __init__(self):
        self.raiz = Tk()
        self.raiz.title("<- Método Euler ->")
        self.raiz.resizable(0,0)

        fuente = font.Font(weight='bold')
        self.marco = ttk.Frame(self.raiz,borderwidth=2, relief="groove", padding=(10,10))

        self.ecua = ttk.Label(self.marco, text="Ecuación: ",
                               font= tkinter.font.Font(family="Courier", size=16, weight="bold", slant="italic"), padding=(5, 5))
        self.etiq1 = ttk.Label(self.marco, text="Valor del incremento h: ",
                               font=fuente, padding=(5,5))
        self.etiq2 = ttk.Label(self.marco, text="Valor final de X: ",
                               font=fuente,padding=(5,5))
        self.etiq3 = ttk.Label(self.marco,text="Valor inicial de Y: ",
                               font=fuente,padding=(10,5))


        self.h = IntVar()
        self.xf = IntVar()
        self.yi = IntVar()
        self.ecuacion = StringVar()
        self.ecuacion.set("x-y+4")

        self.ecuaText = ttk.Label(self.marco, font= tkinter.font.Font(family="Courier", size=16, weight="bold", slant="italic"),
                                textvariable=self.ecuacion,
                                padding=(40,5))

        self.ctext1   = ttk.Entry(self.marco,
                                textvariable=self.h,
                                width=30)
        self.ctext2   = ttk.Entry(self.marco,
                                textvariable=self.xf,
                                width=30)
        self.ctext3   = ttk.Entry(self.marco,
                                textvariable=self.yi,
                                width=30)

        self.boton1   = ttk.Button(self.marco, text="Calcular",padding=(5,5),
                                 command=self.enviar)

        self.boton2   = ttk.Button(self.marco, text="Salir",padding=(5,5),
                                 command=quit)

        self.marco.grid(column=0, row=0)
        self.ecua.grid(column=3, row=0)
        self.ecuaText.grid(column=3, row=1)
        self.etiq1.grid(column=0, row=0)
        self.ctext1.grid(column=1, row=0)
        self.etiq2.grid(column=0, row=1)
        self.ctext2.grid(column=1, row=1)
        self.etiq3.grid(column=0, row=2)
        self.ctext3.grid(column=1, row=2)

        self.boton1.grid(column=1, row=4)
        self.boton2.grid(column=2, row=4)

        self.ctext1.focus_set()

        self.raiz.mainloop()

    def enviar(self):
        self.auxH = float(self.ctext1.get())
        self.auxXF   = float(self.ctext2.get())
        self.auxYi   = float(self.ctext3.get())
        calcular = Metodo(auxH=self.auxH, auxXF=self.auxXF, auxYi=self.auxYi)



def main():
    mi_app = Aplicacion()
    return 0


if __name__ == '__main__':
    main()