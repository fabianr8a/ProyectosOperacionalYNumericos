function z=funcion_ejemplo(x,y)
z=cos(2*x)+sin(3*x);
end